# GGTH LSTM Trading System - Universal Edition

## Installation Complete!

System configured for: Windows 10

### Quick Start

Run the launcher:
```bash
python launcher.py
```

Or on Windows, double-click: `GGTH_Launcher.bat`

### Next Steps

1. **Train the model**: Choose option 1 in launcher
2. **Start daemon**: Choose option 2 in launcher  
3. **Copy EA**: Copy GGTH8-5.mq5 to MT5 Experts folder
4. **Start trading**: Load EA in MetaTrader 5

### Files Created

- config.json (auto-detected paths)
- path_helper.py (universal path management)
- launcher.py (easy interface)
- models/ (for trained models)
- data/ (communication folder)

### Troubleshooting

- Re-run installer: `python install.py`
- Check config.json for paths
- Ensure MT5 has file access permissions

System ready!
