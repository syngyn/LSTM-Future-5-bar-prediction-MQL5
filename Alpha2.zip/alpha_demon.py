#!/usr/bin/env python3
"""
Hybrid ALFA-Transformer Daemon
==============================
Serves predictions from the trained hybrid model to the MT5 EA.
"""
import os
import json
import time
import torch
import joblib
import numpy as np
import math
import traceback
from torch import nn
import sys
warnings.filterwarnings('ignore')

# --- CONFIGURATION ---
def find_mql5_files_path():
    appdata = os.getenv('APPDATA')
    if not appdata or 'win' not in sys.platform: return None
    for term in os.listdir(os.path.join(appdata, 'MetaQuotes', 'Terminal')):
        if os.path.isdir(os.path.join(appdata, 'MetaQuotes', 'Terminal', term)) and len(term) > 30:
            return os.path.join(appdata, 'MetaQuotes', 'Terminal', term, 'MQL5', 'Files')
    return None

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(SCRIPT_DIR, "models")
COMM_DIR = find_mql5_files_path() or SCRIPT_DIR
DATA_DIR = os.path.join(COMM_DIR, "LSTM_Trading", "data")
print(f"--> Using Communication Path: {DATA_DIR}")

# --- MODEL FILE PATHS ---
MODEL_FILE = os.path.join(MODEL_DIR, "hybrid_model.pth")
SCALER_FEATURE_FILE = os.path.join(MODEL_DIR, "scaler.pkl")
SCALER_REGRESSION_FILE = os.path.join(MODEL_DIR, "scaler_regression.pkl")

# --- CONSTANTS ---
INPUT_FEATURES, HIDDEN_SIZE, NUM_LAYERS, SEQ_LEN = 15, 128, 3, 20
OUTPUT_STEPS, NUM_CLASSES = 5, 3

# --- HYBRID MODEL ARCHITECTURE (Must match training script) ---
# ... (The HybridModel and PositionalEncoding classes are identical to the training script)
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

class HybridModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, num_regression_outputs, nhead=8, dropout=0.2):
        super(HybridModel, self).__init__()
        self.hidden_size = hidden_size
        self.alfa_input_norm = nn.LayerNorm(input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout if num_layers > 1 else 0)
        self.lstm_norm = nn.LayerNorm(hidden_size)
        self.attention = nn.MultiheadAttention(hidden_size, num_heads=nhead, dropout=dropout, batch_first=True)
        self.alfa_norm = nn.LayerNorm(hidden_size)
        self.transformer_input_embedding = nn.Linear(input_size, hidden_size)
        self.pos_encoder = PositionalEncoding(hidden_size, dropout)
        encoder_layers = nn.TransformerEncoderLayer(d_model=hidden_size, nhead=nhead, dim_feedforward=hidden_size*4, dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=num_layers)
        self.transformer_norm = nn.LayerNorm(hidden_size)
        self.fusion_layer = nn.Sequential(nn.Linear(hidden_size * 2, hidden_size), nn.GELU(), nn.Dropout(dropout))
        self.regression_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_regression_outputs))
        self.classification_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_classes))
        self.uncertainty_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_regression_outputs))
        self.confidence_head = nn.Sequential(nn.Linear(hidden_size, 1), nn.Sigmoid())

    def forward(self, x):
        alfa_x = self.alfa_input_norm(x)
        lstm_out, _ = self.lstm(alfa_x)
        lstm_out = self.lstm_norm(lstm_out)
        attn_out, _ = self.attention(lstm_out, lstm_out, lstm_out)
        alfa_features = self.alfa_norm(attn_out)
        transformer_x = self.transformer_input_embedding(x) * math.sqrt(self.hidden_size)
        transformer_x = self.pos_encoder(transformer_x)
        transformer_out = self.transformer_encoder(transformer_x)
        transformer_features = self.transformer_norm(transformer_out)
        alfa_last_step = alfa_features[:, -1, :]
        transformer_last_step = transformer_features[:, -1, :]
        combined_features = torch.cat((alfa_last_step, transformer_last_step), dim=1)
        fused_representation = self.fusion_layer(combined_features)
        regression_output = self.regression_head(fused_representation)
        classification_logits = self.classification_head(fused_representation)
        uncertainty = torch.exp(self.uncertainty_head(fused_representation))
        model_confidence = self.confidence_head(fused_representation)
        return regression_output, classification_logits, uncertainty, model_confidence, None

# --- DAEMON CLASS ---
class HybridDaemon:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🚀 Using device: {self.device}")
        self.model = HybridModel(INPUT_FEATURES, HIDDEN_SIZE, NUM_LAYERS, NUM_CLASSES, OUTPUT_STEPS)
        self.model.load_state_dict(torch.load(MODEL_FILE, map_location=self.device))
        self.model.to(self.device).eval()
        self.scaler_feature = joblib.load(SCALER_FEATURE_FILE)
        self.scaler_regressor_target = joblib.load(SCALER_REGRESSION_FILE)
        print("✅ Hybrid model and scalers loaded successfully.")

    def get_prediction(self, features, current_price, atr):
        try:
            scaled_features = self.scaler_feature.transform(np.array(features).reshape(1, -1))
            scaled_sequence = scaled_features.reshape(1, SEQ_LEN, INPUT_FEATURES)
            tensor = torch.tensor(scaled_sequence, dtype=torch.float32).to(self.device)

            with torch.no_grad():
                pred, logits, _, conf, _ = self.model(tensor)
                unscaled_pred = self.scaler_regressor_target.inverse_transform(pred.cpu().numpy().reshape(1, -1))[0]
                probs = torch.softmax(logits, dim=1)[0].cpu().numpy()
            
            return {
                "predicted_prices": [float(p) for p in unscaled_pred],
                "confidence_score": float(conf.item()),
                "buy_probability": float(probs[2]),
                "sell_probability": float(probs[0]), 
                "hold_probability": float(probs[1]),
                "prediction_source": "Hybrid",
                "status": "success"
            }
        except Exception as e:
            traceback.print_exc()
            return {"status": "error", "error_message": str(e)}

    def run(self):
        print("\n🎯 Hybrid ALFA-Transformer Daemon v3.1 is running!")
        os.makedirs(DATA_DIR, exist_ok=True)
        while True:
            for filename in os.listdir(DATA_DIR):
                if filename.startswith("request_") and filename.endswith(".json"):
                    filepath = os.path.join(DATA_DIR, filename)
                    try:
                        with open(filepath, 'r') as f: data = json.load(f)
                        request_id = data.get("request_id")
                        response = self.get_prediction(data["features"], data["current_price"], data["atr"])
                        response["request_id"] = request_id
                        
                        with open(os.path.join(DATA_DIR, f"response_{request_id}.json"), 'w') as f:
                            json.dump(response, f)
                        os.remove(filepath)
                    except Exception as e:
                        print(f"Error processing {filename}: {e}")
                        try: os.remove(filepath)
                        except: pass
            time.sleep(0.1)

if __name__ == "__main__":
    try:
        HybridDaemon().run()
    except Exception as e:
        print(f"💥 Fatal error starting daemon: {e}")
        sys.exit(1)