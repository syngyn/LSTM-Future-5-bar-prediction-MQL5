#!/usr/bin/env python3
"""
Hybrid ALFA-Transformer Training Script
=======================================
Trains the integrated Hybrid Model, which fuses the capabilities of
an Attention-based LSTM and a Transformer encoder.
"""
import os
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'

import pandas as pd
import numpy as np
import math
from sklearn.preprocessing import StandardScaler, RobustScaler
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import joblib
import sys
import traceback
import warnings
warnings.filterwarnings('ignore')

# --- HYBRID MODEL ARCHITECTURE ---
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

class HybridModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, num_regression_outputs, nhead=8, dropout=0.2):
        super(HybridModel, self).__init__()
        self.hidden_size = hidden_size
        self.alfa_input_norm = nn.LayerNorm(input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout if num_layers > 1 else 0)
        self.lstm_norm = nn.LayerNorm(hidden_size)
        self.attention = nn.MultiheadAttention(hidden_size, num_heads=nhead, dropout=dropout, batch_first=True)
        self.alfa_norm = nn.LayerNorm(hidden_size)
        self.transformer_input_embedding = nn.Linear(input_size, hidden_size)
        self.pos_encoder = PositionalEncoding(hidden_size, dropout)
        encoder_layers = nn.TransformerEncoderLayer(d_model=hidden_size, nhead=nhead, dim_feedforward=hidden_size*4, dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=num_layers)
        self.transformer_norm = nn.LayerNorm(hidden_size)
        self.fusion_layer = nn.Sequential(nn.Linear(hidden_size * 2, hidden_size), nn.GELU(), nn.Dropout(dropout))
        self.regression_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_regression_outputs))
        self.classification_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_classes))
        self.uncertainty_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_regression_outputs))
        self.confidence_head = nn.Sequential(nn.Linear(hidden_size, 1), nn.Sigmoid())

    def forward(self, x):
        alfa_x = self.alfa_input_norm(x)
        lstm_out, _ = self.lstm(alfa_x)
        lstm_out = self.lstm_norm(lstm_out)
        attn_out, _ = self.attention(lstm_out, lstm_out, lstm_out)
        alfa_features = self.alfa_norm(attn_out)
        transformer_x = self.transformer_input_embedding(x) * math.sqrt(self.hidden_size)
        transformer_x = self.pos_encoder(transformer_x)
        transformer_out = self.transformer_encoder(transformer_x)
        transformer_features = self.transformer_norm(transformer_out)
        alfa_last_step = alfa_features[:, -1, :]
        transformer_last_step = transformer_features[:, -1, :]
        combined_features = torch.cat((alfa_last_step, transformer_last_step), dim=1)
        fused_representation = self.fusion_layer(combined_features)
        regression_output = self.regression_head(fused_representation)
        classification_logits = self.classification_head(fused_representation)
        uncertainty = torch.exp(self.uncertainty_head(fused_representation))
        model_confidence = self.confidence_head(fused_representation)
        return regression_output, classification_logits, uncertainty, model_confidence, None

# --- UNIFIED FEATURE CREATION ---
def create_unified_features(df):
    print("🔧 Creating unified features...")
    features_df = pd.DataFrame(index=df.index)
    for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
        if col not in df.columns: df[col] = 1.0
    features_df['price_return'] = df['Close'].pct_change()
    features_df['Volume'] = df['Volume']
    tr = pd.concat([df['High'] - df['Low'], abs(df['High'] - df['Close'].shift(1)), abs(df['Low'] - df['Close'].shift(1))], axis=1).max(axis=1)
    features_df['atr'] = tr.rolling(14).mean()
    ema12 = df['Close'].ewm(span=12, adjust=False).mean(); ema26 = df['Close'].ewm(span=26, adjust=False).mean()
    features_df['macd'] = ema12 - ema26
    delta = df['Close'].diff()
    gain = delta.clip(lower=0).rolling(window=14).mean(); loss = -delta.clip(upper=0).abs().rolling(window=14).mean()
    features_df['rsi'] = 100 - (100 / (1 + (gain / (loss + 1e-10))))
    low14, high14 = df['Low'].rolling(14).min(), df['High'].rolling(14).max()
    features_df['stoch_k'] = 100 * (df['Close'] - low14) / (high14 - low14 + 1e-10)
    tp = (df['High'] + df['Low'] + df['Close']) / 3
    tp_ma = tp.rolling(20).mean(); tp_md = tp.rolling(20).apply(lambda x: np.abs(x - x.mean()).mean(), raw=True)
    features_df['cci'] = (tp - tp_ma) / (0.015 * tp_md + 1e-10)
    features_df['hour'] = df.index.hour; features_df['day_of_week'] = df.index.dayofweek
    features_df['usd_strength'] = df['Close'].pct_change().rolling(5).mean()
    features_df['eur_strength'] = -df['Close'].pct_change().rolling(5).mean(); features_df['jpy_strength'] = 0.0
    bb_std = df['Close'].rolling(20).std()
    features_df['bb_width'] = bb_std / (df['Close'].rolling(20).mean() + 1e-10)
    features_df['volume_change'] = df['Volume'].pct_change(periods=5)
    features_df['candle_type'] = abs(df['Close'] - df['Open']) / (df['High'] - df['Low'] + 1e-10)
    features_df = features_df.replace([np.inf, -np.inf], np.nan).dropna()
    feature_names = ['price_return', 'Volume', 'atr', 'macd', 'rsi', 'stoch_k', 'cci', 'hour', 'day_of_week', 'usd_strength', 'eur_strength', 'jpy_strength', 'bb_width', 'volume_change', 'candle_type']
    features_df = features_df[feature_names]
    aligned_main_df = df.loc[features_df.index].copy()
    print(f"✅ Created {len(features_df.columns)} features. Final data points: {len(features_df):,}")
    return aligned_main_df, features_df

# --- LOSS FUNCTIONS ---
class UncertaintyLoss(nn.Module):
    def forward(self, pred, targ, unc): return torch.mean(0.5 * torch.exp(-unc) * (pred - targ)**2 + 0.5 * unc)
class FocalLoss(nn.Module):
    def __init__(self, alpha=1.0, gamma=2.0): super().__init__(); self.alpha, self.gamma = alpha, gamma
    def forward(self, inp, targ):
        ce = F.cross_entropy(inp, targ, reduction='none'); pt = torch.exp(-ce)
        return torch.mean(self.alpha * (1 - pt)**self.gamma * ce)

# --- CONFIGURATION ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_SAVE_PATH = os.path.join(SCRIPT_DIR, "models")
DATA_FILES = ["EURUSD60.csv", "EURUSD.csv", "eurusd_h1.csv", "eur sample data to format correctly.csv"] # Added your filename
INPUT_FEATURES, HIDDEN_SIZE, NUM_LAYERS, SEQ_LEN = 15, 128, 3, 20
OUTPUT_STEPS, NUM_CLASSES, EPOCHS, BATCH_SIZE, LR = 5, 3, 50, 64, 0.001
PROFIT_THRESHOLD_ATR = 0.75

def load_and_prepare_data():
    """Load and prepare training data, handling various CSV formats."""
    data_file = next((os.path.join(SCRIPT_DIR, f) for f in DATA_FILES if os.path.exists(os.path.join(SCRIPT_DIR, f))), None)
    if not data_file:
        print(f"❌ No data file found. Looking for: {DATA_FILES}")
        return None
    
    print(f"📁 Using data file: {os.path.basename(data_file)}")
    
    # --- BOM FIX: Read CSV with 'utf-8-sig' encoding ---
    df = pd.read_csv(data_file, encoding='utf-8-sig')
    
    # Clean column names (remove brackets, capitalize)
    df.rename(columns=lambda x: x.strip().replace('<','').replace('>','').capitalize(), inplace=True)
    
    # Combine Date and Time if they exist
    if 'Date' in df.columns and 'Time' in df.columns:
        print("   - Combining 'Date' and 'Time' columns.")
        df['Datetime'] = pd.to_datetime(df['Date'] + ' ' + df['Time'], errors='coerce')
        df.set_index('Datetime', inplace=True)
    else:
        date_col = next((c for c in ['Datetime', 'Date', 'Timestamp'] if c in df.columns), None)
        if not date_col:
            print("❌ No valid date/time column found.")
            return None
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        df.set_index(date_col, inplace=True)
        
    df.sort_index(inplace=True)
    if 'Tickvol' in df.columns and 'Volume' not in df.columns: df.rename(columns={'Tickvol': 'Volume'}, inplace=True)
    
    # Force numeric conversion and clean data
    numeric_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
    for col in numeric_cols:
        if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
    df.dropna(subset=numeric_cols, inplace=True)
    
    return df

def create_targets(main_df):
    print("🎯 Creating targets...")
    regr_targets = [main_df['Close'].shift(-i) for i in range(1, OUTPUT_STEPS + 1)]
    regr_df = pd.concat(regr_targets, axis=1)
    regr_df.columns = [f'target_{i}' for i in range(OUTPUT_STEPS)]
    
    atr = (pd.concat([main_df['High'] - main_df['Low'], abs(main_df['High'] - main_df['Close'].shift(1)), abs(main_df['Low'] - main_df['Close'].shift(1))], axis=1).max(axis=1)).rolling(14).mean()
    future_price = main_df['Close'].shift(-OUTPUT_STEPS)
    conditions = [future_price > main_df['Close'] + atr * PROFIT_THRESHOLD_ATR, future_price < main_df['Close'] - atr * PROFIT_THRESHOLD_ATR]
    class_s = pd.Series(np.select(conditions, [2, 0], default=1), index=main_df.index, name='target_class')
    
    combined = main_df.join(regr_df).join(class_s).dropna()
    print(f"📊 Class distribution: {np.bincount(combined['target_class'].astype(int).values)}")
    return combined

def prepare_sequences(features_df, targets_df):
    print("🔗 Building sequences...")
    X = features_df.loc[targets_df.index].values
    y_regr = targets_df[[f'target_{i}' for i in range(OUTPUT_STEPS)]].values
    y_class = targets_df['target_class'].values
    
    f_scaler = StandardScaler().fit(X); t_scaler = StandardScaler().fit(y_regr)
    X_scaled, y_regr_scaled = f_scaler.transform(X), t_scaler.transform(y_regr)
    
    X_seq, y_r_seq, y_c_seq = [], [], []
    for i in range(len(X_scaled) - SEQ_LEN):
        X_seq.append(X_scaled[i:i + SEQ_LEN])
        y_r_seq.append(y_regr_scaled[i + SEQ_LEN - 1])
        y_c_seq.append(y_class[i + SEQ_LEN - 1])
    
    print(f"✅ Created {len(X_seq):,} sequences")
    return (torch.tensor(np.array(X_seq), dtype=torch.float32),
            torch.tensor(np.array(y_r_seq), dtype=torch.float32),
            torch.tensor(np.array(y_c_seq), dtype=torch.long),
            f_scaler, t_scaler)

def train_model(model, train_loader, val_loader, device, model_name="main"):
    print(f"🎯 Training Hybrid Model ({model_name})...")
    regr_loss_fn, class_loss_fn = UncertaintyLoss(), FocalLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=5)
    best_val_loss = float('inf'); best_model_state = None

    for epoch in range(EPOCHS):
        model.train(); train_loss = 0
        for X_b, y_r_b, y_c_b in train_loader:
            X_b, y_r_b, y_c_b = X_b.to(device), y_r_b.to(device), y_c_b.to(device)
            optimizer.zero_grad()
            p_r, p_c, p_u, _, _ = model(X_b)
            loss = regr_loss_fn(p_r, y_r_b, p_u) + class_loss_fn(p_c, y_c_b)
            loss.backward(); optimizer.step(); train_loss += loss.item()
        
        model.eval(); val_loss = 0
        with torch.no_grad():
            for X_b, y_r_b, y_c_b in val_loader:
                X_b, y_r_b, y_c_b = X_b.to(device), y_r_b.to(device), y_c_b.to(device)
                p_r, p_c, p_u, _, _ = model(X_b)
                val_loss += (regr_loss_fn(p_r, y_r_b, p_u) + class_loss_fn(p_c, y_c_b)).item()
        
        val_loss /= len(val_loader); scheduler.step(val_loss)
        print(f"Epoch {epoch+1:2d}/{EPOCHS} | Train Loss: {train_loss/len(train_loader):.4f} | Val Loss: {val_loss:.4f} | LR: {optimizer.param_groups[0]['lr']:.6f}")
        if val_loss < best_val_loss:
            best_val_loss = val_loss; best_model_state = model.state_dict().copy()
            
    if best_model_state: model.load_state_dict(best_model_state)
    return model

def main():
    print("🚀 Hybrid ALFA-Transformer Training Script v3.1")
    print("=" * 70)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🔥 Using device: {device}")
    
    main_df = load_and_prepare_data()
    if main_df is None:
        print("💥 Exiting due to data loading failure.")
        return
    
    main_df, features_df = create_unified_features(main_df)
    targets_df = create_targets(main_df)
    X, y_r, y_c, f_scaler, t_scaler = prepare_sequences(features_df, targets_df)
    train_dataset = TensorDataset(X, y_r, y_c)
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_set, val_set = torch.utils.data.random_split(train_dataset, [train_size, val_size])
    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=BATCH_SIZE)
    
    os.makedirs(MODEL_SAVE_PATH, exist_ok=True)
    model = HybridModel(INPUT_FEATURES, HIDDEN_SIZE, NUM_LAYERS, NUM_CLASSES, OUTPUT_STEPS).to(device)
    model = train_model(model, train_loader, val_loader, device)
    
    torch.save(model.state_dict(), os.path.join(MODEL_SAVE_PATH, "hybrid_model.pth"))
    joblib.dump(f_scaler, os.path.join(MODEL_SAVE_PATH, "scaler.pkl"))
    joblib.dump(t_scaler, os.path.join(MODEL_SAVE_PATH, "scaler_regression.pkl"))
    print("✅ Models and scalers saved successfully.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n💥 Training failed: {e}")
        traceback.print_exc()
