#!/usr/bin/env python3
"""
Hybrid ALFA-Transformer Backtest Data Generator
===============================================
Generates backtest_predictions.csv for the MT5 Strategy Tester using the hybrid model.
"""
import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import joblib
import math
import traceback
import warnings
warnings.filterwarnings('ignore')

# --- CONFIGURATION ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(SCRIPT_DIR, "models")
OUTPUT_FILE = "backtest_predictions.csv"
DATA_FILES = ["EURUSD60.csv", "EURUSD.csv", "eurusd_h1.csv", "eur sample data to format correctly.csv"] # Added your filename
INPUT_FEATURES, HIDDEN_SIZE, NUM_LAYERS, SEQ_LEN = 15, 128, 3, 20
OUTPUT_STEPS, NUM_CLASSES = 5, 3
MIN_CONFIDENCE = 0.3

# --- HYBRID MODEL ARCHITECTURE (Must match training script) ---
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

class HybridModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, num_regression_outputs, nhead=8, dropout=0.2):
        super(HybridModel, self).__init__()
        self.hidden_size = hidden_size
        self.alfa_input_norm = nn.LayerNorm(input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout if num_layers > 1 else 0)
        self.lstm_norm = nn.LayerNorm(hidden_size)
        self.attention = nn.MultiheadAttention(hidden_size, num_heads=nhead, dropout=dropout, batch_first=True)
        self.alfa_norm = nn.LayerNorm(hidden_size)
        self.transformer_input_embedding = nn.Linear(input_size, hidden_size)
        self.pos_encoder = PositionalEncoding(hidden_size, dropout)
        encoder_layers = nn.TransformerEncoderLayer(d_model=hidden_size, nhead=nhead, dim_feedforward=hidden_size*4, dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=num_layers)
        self.transformer_norm = nn.LayerNorm(hidden_size)
        self.fusion_layer = nn.Sequential(nn.Linear(hidden_size * 2, hidden_size), nn.GELU(), nn.Dropout(dropout))
        self.regression_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_regression_outputs))
        self.classification_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_classes))
        self.uncertainty_head = nn.Sequential(nn.Linear(hidden_size, hidden_size // 2), nn.ReLU(), nn.Linear(hidden_size // 2, num_regression_outputs))
        self.confidence_head = nn.Sequential(nn.Linear(hidden_size, 1), nn.Sigmoid())

    def forward(self, x):
        alfa_x = self.alfa_input_norm(x)
        lstm_out, _ = self.lstm(alfa_x)
        lstm_out = self.lstm_norm(lstm_out)
        attn_out, _ = self.attention(lstm_out, lstm_out, lstm_out)
        alfa_features = self.alfa_norm(attn_out)
        transformer_x = self.transformer_input_embedding(x) * math.sqrt(self.hidden_size)
        transformer_x = self.pos_encoder(transformer_x)
        transformer_out = self.transformer_encoder(transformer_x)
        transformer_features = self.transformer_norm(transformer_out)
        alfa_last_step = alfa_features[:, -1, :]
        transformer_last_step = transformer_features[:, -1, :]
        combined_features = torch.cat((alfa_last_step, transformer_last_step), dim=1)
        fused_representation = self.fusion_layer(combined_features)
        regression_output = self.regression_head(fused_representation)
        classification_logits = self.classification_head(fused_representation)
        uncertainty = torch.exp(self.uncertainty_head(fused_representation))
        model_confidence = self.confidence_head(fused_representation)
        return regression_output, classification_logits, uncertainty, model_confidence, None

# --- UNIFIED FEATURE CREATION ---
def create_unified_features(df):
    print("🔧 Creating unified features...")
    features_df = pd.DataFrame(index=df.index)
    for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
        if col not in df.columns: df[col] = 1.0
    features_df['price_return'] = df['Close'].pct_change()
    features_df['Volume'] = df['Volume']
    tr = pd.concat([df['High'] - df['Low'], abs(df['High'] - df['Close'].shift(1)), abs(df['Low'] - df['Close'].shift(1))], axis=1).max(axis=1)
    features_df['atr'] = tr.rolling(14).mean()
    ema12 = df['Close'].ewm(span=12, adjust=False).mean(); ema26 = df['Close'].ewm(span=26, adjust=False).mean()
    features_df['macd'] = ema12 - ema26
    delta = df['Close'].diff()
    gain = delta.clip(lower=0).rolling(window=14).mean(); loss = -delta.clip(upper=0).abs().rolling(window=14).mean()
    features_df['rsi'] = 100 - (100 / (1 + (gain / (loss + 1e-10))))
    low14, high14 = df['Low'].rolling(14).min(), df['High'].rolling(14).max()
    features_df['stoch_k'] = 100 * (df['Close'] - low14) / (high14 - low14 + 1e-10)
    tp = (df['High'] + df['Low'] + df['Close']) / 3
    tp_ma = tp.rolling(20).mean(); tp_md = tp.rolling(20).apply(lambda x: np.abs(x - x.mean()).mean(), raw=True)
    features_df['cci'] = (tp - tp_ma) / (0.015 * tp_md + 1e-10)
    features_df['hour'] = df.index.hour; features_df['day_of_week'] = df.index.dayofweek
    features_df['usd_strength'] = df['Close'].pct_change().rolling(5).mean()
    features_df['eur_strength'] = -df['Close'].pct_change().rolling(5).mean(); features_df['jpy_strength'] = 0.0
    bb_std = df['Close'].rolling(20).std()
    features_df['bb_width'] = bb_std / (df['Close'].rolling(20).mean() + 1e-10)
    features_df['volume_change'] = df['Volume'].pct_change(periods=5)
    features_df['candle_type'] = abs(df['Close'] - df['Open']) / (df['High'] - df['Low'] + 1e-10)
    features_df = features_df.replace([np.inf, -np.inf], np.nan).dropna()
    feature_names = ['price_return', 'Volume', 'atr', 'macd', 'rsi', 'stoch_k', 'cci', 'hour', 'day_of_week', 'usd_strength', 'eur_strength', 'jpy_strength', 'bb_width', 'volume_change', 'candle_type']
    features_df = features_df[feature_names]
    aligned_main_df = df.loc[features_df.index].copy()
    print(f"✅ Created {len(features_df.columns)} features. Final data points: {len(features_df):,}")
    return aligned_main_df, features_df

class BacktestGenerator:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🚀 Using device: {self.device}")
        self.model = None; self.scaler_feature = None; self.scaler_target = None
        self._load_assets()

    def _load_assets(self):
        print("🔄 Loading Hybrid Model and scalers...")
        try:
            self.model = HybridModel(INPUT_FEATURES, HIDDEN_SIZE, NUM_LAYERS, NUM_CLASSES, OUTPUT_STEPS)
            self.model.load_state_dict(torch.load(os.path.join(MODEL_DIR, "hybrid_model.pth"), map_location=self.device))
            self.model.to(self.device).eval()
            self.scaler_feature = joblib.load(os.path.join(MODEL_DIR, "scaler.pkl"))
            self.scaler_target = joblib.load(os.path.join(MODEL_DIR, "scaler_regression.pkl"))
            print("✅ Assets loaded successfully.")
        except Exception as e:
            print(f"💥 FATAL: Could not load assets: {e}"); raise

    def load_data(self):
        data_file = next((os.path.join(SCRIPT_DIR, f) for f in DATA_FILES if os.path.exists(os.path.join(SCRIPT_DIR, f))), None)
        if not data_file:
            print(f"❌ No data file found. Looking for: {DATA_FILES}")
            return None
        
        print(f"📁 Loading data from {os.path.basename(data_file)}...")
        # --- BOM FIX: Read CSV with 'utf-8-sig' encoding ---
        df = pd.read_csv(data_file, encoding='utf-8-sig')
        
        df.rename(columns=lambda x: x.strip().replace('<','').replace('>','').capitalize(), inplace=True)
        
        if 'Date' in df.columns and 'Time' in df.columns:
            df['Datetime'] = pd.to_datetime(df['Date'] + ' ' + df['Time'], errors='coerce')
            df.set_index('Datetime', inplace=True)
        else:
            date_col = next((c for c in ['Datetime', 'Date', 'Timestamp'] if c in df.columns), None)
            if not date_col: return None
            df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
            df.set_index(date_col, inplace=True)
            
        df.sort_index(inplace=True)
        if 'Tickvol' in df.columns: df.rename(columns={'Tickvol': 'Volume'}, inplace=True)
        
        numeric_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
        for col in numeric_cols:
            if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(subset=numeric_cols, inplace=True)
        
        print(f"✅ Loaded {len(df)} bars.")
        return df

    def generate_predictions(self, main_df, features_df):
        print("🎯 Generating predictions...")
        sequences, timestamps, prices = [], [], []
        price_data = main_df.loc[features_df.index]['Close']
        
        for i in range(SEQ_LEN, len(features_df)):
            sequences.append(features_df.iloc[i-SEQ_LEN:i].values)
            timestamps.append(features_df.index[i])
            prices.append(price_data.iloc[i])
            
        scaled_sequences = self.scaler_feature.transform(np.array(sequences).reshape(-1, INPUT_FEATURES)).reshape(-1, SEQ_LEN, INPUT_FEATURES)
        tensor = torch.tensor(scaled_sequences, dtype=torch.float32).to(self.device)
        
        with torch.no_grad():
            reg, logits, _, conf, _ = self.model(tensor)
        
        predictions = []
        for i in range(len(reg)):
            unscaled = self.scaler_target.inverse_transform(reg[i].cpu().numpy().reshape(1, -1))[0]
            probs = torch.softmax(logits[i], dim=0).cpu().numpy()
            predictions.append({
                'timestamp': timestamps[i],
                'buy_prob': probs[2], 'sell_prob': probs[0], 'hold_prob': probs[1],
                'confidence': max(MIN_CONFIDENCE, conf[i].item()),
                'predicted_prices': unscaled
            })
        print(f"✅ Generated {len(predictions)} predictions.")
        return predictions

    def save_to_csv(self, predictions):
        print(f"💾 Saving predictions to {OUTPUT_FILE}...")
        rows = [[p['timestamp'].strftime("%Y.%m.%d %H:%M:%S"), p['buy_prob'], p['sell_prob'], p['hold_prob'], p['confidence'], *p['predicted_prices']] for p in predictions]
        columns = ['timestamp', 'buy_prob', 'sell_prob', 'hold_prob', 'confidence_score'] + [f'price_{i+1}' for i in range(OUTPUT_STEPS)]
        df = pd.DataFrame(rows, columns=columns)
        df.to_csv(os.path.join(SCRIPT_DIR, OUTPUT_FILE), sep=';', index=False, float_format='%.8f')
        print(f"✅ Saved {len(df)} predictions.")

    def run(self):
        df = self.load_data()
        if df is None: return
        main_df, features_df = create_unified_features(df)
        predictions = self.generate_predictions(main_df, features_df)
        self.save_to_csv(predictions)
        print("\n🎉 BACKTEST DATA GENERATION COMPLETE!")

if __name__ == "__main__":
    try:
        BacktestGenerator().run()
    except Exception as e:
        print(f"\n💥 An error occurred: {e}"); traceback.print_exc()