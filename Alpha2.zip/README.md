# Hybrid ALFA-Transformer EA - Integrated Edition

## ✅ Installation Complete!

System configured for: **Windows 10**

This system uses a single, powerful **Hybrid Model** that combines the strengths of Attention-based LSTMs (ALFA) and Transformers. You no longer need to choose a model type.

The required training data (`EURUSD60.csv`) has been automatically downloaded.

---

### 🚀 Quick Start Guide

1.  **Run the Launcher**
    - **On Windows:** Double-click `Hybrid_EA_Launcher.bat`
    - **On macOS/Linux:** Open a terminal and run `./Hybrid_EA_Launcher.sh`

2.  **Train the Hybrid Model**
    - In the launcher, choose option `1` and press Enter.

3.  **Start the Daemon**
    - In the launcher, choose option `2` and press Enter.

4.  **Set up MetaTrader 5**
    - Copy `Hybrid_ALFA_Transformer_EA.mq5` to your MT5 `Experts` folder and compile it.
    - Attach the EA to a EURUSD, H1 chart.

---

### Updating Training Data

To get the latest market data for training, simply run the installer again by choosing option `4` in the launcher. This will re-download the `EURUSD60.csv` file.

### Backtesting

1.  After training, run the launcher and choose option `3` to generate `backtest_predictions.csv`.
2.  Copy this CSV to your MT5 `Common\Files` directory.
3.  Run the EA in the Strategy Tester.
