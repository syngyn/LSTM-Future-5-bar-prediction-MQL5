#!/usr/bin/env python3
import sys
import subprocess
from pathlib import Path

def main():
    script_dir = Path(__file__).parent
    
    print("GGTH LSTM Trading System")
    print("=" * 30)
    print("1. train    - Train model")
    print("2. daemon   - Start daemon")
    print("3. backtest - Generate backtest")
    print("4. install  - Run installer")
    print()
    
    while True:
        choice = input("Command (or 'quit'): ").strip().lower()
        
        if choice in ['quit', 'q']:
            break
        elif choice in ['1', 'train']:
            subprocess.run([sys.executable, script_dir / "train_enhanced_model.py"])
        elif choice in ['2', 'daemon']:
            subprocess.run([sys.executable, script_dir / "daemon.py"])
        elif choice in ['3', 'backtest']:
            subprocess.run([sys.executable, script_dir / "generate_backtest.py"])
        elif choice in ['4', 'install']:
            subprocess.run([sys.executable, script_dir / "install.py"])
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
