
import pandas as pd
import numpy as np

def load_and_align_data(file_dict, base_path):
    dfs = []
    for symbol, filename in file_dict.items():
        filepath = f"{base_path}/{filename}"
        df = pd.read_csv(filepath, sep=';', header=None)
        df.columns = ["timestamp", "open", "high", "low", "close", "volume"]
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df.set_index("timestamp", inplace=True)
        df.columns = [f"{symbol.lower()}_{col}" for col in df.columns]
        dfs.append(df)

    df_merged = pd.concat(dfs, axis=1)
    df_merged = df_merged.dropna()
    return df_merged

def create_features(df):
    df = df.copy()
    df["eurusd_return"] = df["eurusd_close"].pct_change()
    df["eurusd_atr"] = df["eurusd_high"] - df["eurusd_low"]

    # Bollinger Bands
    df["bb_upper"] = df["eurusd_close"].rolling(window=20).mean() + 2 * df["eurusd_close"].rolling(window=20).std()
    df["bb_lower"] = df["eurusd_close"].rolling(window=20).mean() - 2 * df["eurusd_close"].rolling(window=20).std()

    # RSI
    delta = df["eurusd_close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / (avg_loss + 1e-10)
    df["rsi_14"] = 100 - (100 / (1 + rs))

    # CCI
    tp = (df["eurusd_high"] + df["eurusd_low"] + df["eurusd_close"]) / 3
    cci_ma = tp.rolling(window=20).mean()
    cci_md = tp.rolling(window=20).apply(lambda x: np.mean(np.abs(x - np.mean(x))))
    df["cci_20"] = (tp - cci_ma) / (0.015 * cci_md + 1e-10)

    # Stochastic Oscillator (5,3,3)
    low_min = df["eurusd_low"].rolling(window=5).min()
    high_max = df["eurusd_high"].rolling(window=5).max()
    df["stoch_k"] = 100 * ((df["eurusd_close"] - low_min) / (high_max - low_min + 1e-10))
    df["stoch_d"] = df["stoch_k"].rolling(window=3).mean()

    # Moving averages
    df["ma_10"] = df["eurusd_close"].rolling(window=10).mean()
    df["ma_20"] = df["eurusd_close"].rolling(window=20).mean()

    # Drop NaNs from indicator calculations
    df.dropna(inplace=True)

    feature_cols = [
        "eurusd_return", "eurusd_atr",
        "bb_upper", "bb_lower", "rsi_14", "cci_20", "stoch_k", "stoch_d",
        "ma_10", "ma_20"
    ]

    # Add core price inputs
    for col in df.columns:
        if any(key in col for key in ["_open", "_high", "_low", "_close", "_volume"]):
            feature_cols.append(col)

    feature_cols = sorted(list(set(feature_cols)))  # ensure no duplicates
    return df, feature_cols
