#!/usr/bin/env python3
"""
GGTH LSTM Universal Installer
"""
import os
import sys
import platform
import subprocess
from pathlib import Path

def install():
    print("=" * 50)
    print("GGTH LSTM Universal Installer")
    print("=" * 50)
    print("System: " + platform.system())
    print()
    
    # Check Python version
    if sys.version_info < (3, 7):
        print("ERROR: Python 3.7+ required")
        print("Current version: " + sys.version)
        return False
    
    print("Python version OK: " + str(sys.version_info.major) + "." + str(sys.version_info.minor))
    
    # Install packages
    print("Installing Python packages...")
    packages = [
        "torch>=1.9.0",
        "pandas>=1.3.0", 
        "numpy>=1.21.0",
        "scikit-learn>=1.0.0",
        "joblib>=1.0.0",
        "yfinance>=0.1.70",
        "matplotlib>=3.4.0"
    ]
    
    for package in packages:
        try:
            print("  Installing " + package + "...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package], 
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            print("  WARNING: Failed to install " + package)
    
    print("Package installation complete")
    
    # Setup paths
    print("Setting up paths...")
    script_dir = Path(__file__).parent
    sys.path.insert(0, str(script_dir))
    
    try:
        from path_helper import path_manager
        dirs = path_manager.ensure_directories_exist()
        config = path_manager.update_config_paths()
        
        print("Data directory: " + str(path_manager.get_data_dir()))
        print("Model directory: " + str(path_manager.get_model_dir()))
        print("MQL5 communication: " + str(path_manager.get_mql5_files_path()))
        
    except Exception as e:
        print("Path setup issue: " + str(e))
    
    # Create launchers
    print("Creating launchers...")
    
    launcher_py = script_dir / "launcher.py"
    launcher_content = """#!/usr/bin/env python3
import sys
import subprocess
from pathlib import Path

def main():
    script_dir = Path(__file__).parent
    
    print("GGTH LSTM Trading System")
    print("=" * 30)
    print("1. train    - Train model")
    print("2. daemon   - Start daemon")
    print("3. backtest - Generate backtest")
    print("4. install  - Run installer")
    print()
    
    while True:
        choice = input("Command (or 'quit'): ").strip().lower()
        
        if choice in ['quit', 'q']:
            break
        elif choice in ['1', 'train']:
            subprocess.run([sys.executable, script_dir / "train_enhanced_model.py"])
        elif choice in ['2', 'daemon']:
            subprocess.run([sys.executable, script_dir / "daemon.py"])
        elif choice in ['3', 'backtest']:
            subprocess.run([sys.executable, script_dir / "generate_backtest.py"])
        elif choice in ['4', 'install']:
            subprocess.run([sys.executable, script_dir / "install.py"])
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
"""
    
    with open(launcher_py, 'w') as f:
        f.write(launcher_content)
    
    # System-specific launchers
    if platform.system().lower() == "windows":
        batch_file = script_dir / "GGTH_Launcher.bat"
        batch_content = "@echo off\n"
        batch_content += "cd /d \"" + str(script_dir) + "\"\n"
        batch_content += "python launcher.py\n"
        batch_content += "pause\n"
        
        with open(batch_file, 'w') as f:
            f.write(batch_content)
        print("Windows launcher created")
    else:
        shell_file = script_dir / "GGTH_Launcher.sh"
        shell_content = "#!/bin/bash\n"
        shell_content += "cd \"" + str(script_dir) + "\"\n"
        shell_content += "python3 launcher.py\n"
        
        with open(shell_file, 'w') as f:
            f.write(shell_content)
        shell_file.chmod(0o755)
        print("Unix launcher created")
    
    # Download sample data
    print("Setting up sample data...")
    data_file = script_dir / "EURUSD60.csv"
    if not data_file.exists():
        try:
            import yfinance as yf
            import pandas as pd
            
            print("Downloading EURUSD data...")
            eurusd = yf.download("EURUSD=X", period="2y", interval="1h")
            eurusd.reset_index(inplace=True)
            eurusd['Date'] = eurusd['Datetime'].dt.strftime('%Y.%m.%d %H:%M:%S')
            eurusd['TickVol'] = 1000
            eurusd['Vol'] = 1000
            eurusd['Spread'] = 2
            
            eurusd = eurusd[['Date', 'Open', 'High', 'Low', 'Close', 'TickVol', 'Vol', 'Spread']]
            eurusd.to_csv(data_file, index=False)
            print("Sample data downloaded")
            
        except Exception as e:
            print("Could not download data: " + str(e))
            print("Please add EURUSD60.csv manually")
    else:
        print("Training data exists")
    
    # Create README
    print("Creating documentation...")
    readme = script_dir / "README.md"
    readme_content = """# GGTH LSTM Trading System - Universal Edition

## Installation Complete!

System configured for: """ + platform.system() + " " + platform.release() + """

### Quick Start

Run the launcher:
```bash
python launcher.py
```

Or on Windows, double-click: `GGTH_Launcher.bat`

### Next Steps

1. **Train the model**: Choose option 1 in launcher
2. **Start daemon**: Choose option 2 in launcher  
3. **Copy EA**: Copy GGTH8-5.mq5 to MT5 Experts folder
4. **Start trading**: Load EA in MetaTrader 5

### Files Created

- config.json (auto-detected paths)
- path_helper.py (universal path management)
- launcher.py (easy interface)
- models/ (for trained models)
- data/ (communication folder)

### Troubleshooting

- Re-run installer: `python install.py`
- Check config.json for paths
- Ensure MT5 has file access permissions

System ready!
"""
    
    with open(readme, 'w') as f:
        f.write(readme_content)
    
    print("README created")
    
    print()
    print("=" * 50)
    print("INSTALLATION COMPLETE!")
    print("=" * 50)
    print("System configured")
    print("Paths auto-detected")
    print("Launchers created")
    print()
    print("Next steps:")
    print("1. Copy GGTH8-5.mq5 to MT5 Experts folder")
    if platform.system().lower() == "windows":
        print("2. Run: GGTH_Launcher.bat")
    else:
        print("2. Run: ./GGTH_Launcher.sh")
    print("3. Train model and start daemon")
    print()
    
    return True

if __name__ == "__main__":
    success = install()
    if not success:
        input("Press Enter to exit...")
