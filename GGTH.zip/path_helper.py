"""
Universal Path Helper for GGTH LSTM Trading System
"""
import os
import sys
import json
import platform
from pathlib import Path

class PathManager:
    def __init__(self):
        self.script_dir = Path(__file__).parent.absolute()
        self.config_file = self.script_dir / "config.json"
        self.config = self.load_config()
        
    def load_config(self):
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def save_config(self, config):
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            print("Warning: Could not save config: " + str(e))
    
    def get_data_dir(self):
        if 'paths' in self.config and 'data_directory' in self.config['paths']:
            path = Path(self.config['paths']['data_directory'])
            if path.exists():
                return path
        
        fallback = self.script_dir / "data"
        fallback.mkdir(exist_ok=True)
        return fallback
    
    def get_model_dir(self):
        if 'paths' in self.config and 'model_directory' in self.config['paths']:
            path = Path(self.config['paths']['model_directory'])
            if path.exists():
                return path
        
        fallback = self.script_dir / "models"
        fallback.mkdir(exist_ok=True)
        return fallback
    
    def get_mql5_files_path(self):
        if 'paths' in self.config and 'mql5_files' in self.config['paths']:
            mql5_path = self.config['paths']['mql5_files']
            if mql5_path and Path(mql5_path).exists():
                return Path(mql5_path)
        
        detected_path = self.auto_detect_mql5_files()
        if detected_path:
            return detected_path
        
        fallback_dir = self.script_dir / "mql5_communication"
        fallback_dir.mkdir(exist_ok=True)
        return fallback_dir
    
    def auto_detect_mql5_files(self):
        system = platform.system().lower()
        
        if system == "windows":
            appdata = os.getenv('APPDATA')
            if appdata:
                metaquotes_path = Path(appdata) / 'MetaQuotes' / 'Terminal'
                if metaquotes_path.exists():
                    for entry in metaquotes_path.iterdir():
                        if entry.is_dir() and len(entry.name) > 30:
                            mql5_files_path = entry / 'MQL5' / 'Files'
                            if mql5_files_path.exists():
                                return mql5_files_path
        
        return None
    
    def ensure_directories_exist(self):
        dirs = [
            self.get_data_dir(),
            self.get_model_dir(),
            self.get_mql5_files_path() / "LSTM_Trading" / "data"
        ]
        
        for dir_path in dirs:
            dir_path.mkdir(parents=True, exist_ok=True)
        
        return dirs
    
    def update_config_paths(self):
        config = self.config.copy()
        
        if 'paths' not in config:
            config['paths'] = {}
        
        config['paths'].update({
            'script_directory': str(self.script_dir),
            'data_directory': str(self.get_data_dir()),
            'model_directory': str(self.get_model_dir()),
            'mql5_files': str(self.get_mql5_files_path()),
        })
        
        config['system_info'] = {
            'os': platform.system(),
            'platform': platform.platform(),
            'python_version': sys.version,
            'last_updated': str(datetime.now())
        }
        
        self.save_config(config)
        return config

# Global instance
path_manager = PathManager()
