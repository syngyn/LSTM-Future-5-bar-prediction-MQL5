# daemon_fixed.py — auto-detects MT5 Files dir, adds atomic-read & robust checks
import os, json, time, numpy as np, torch, joblib, traceback, sys, hashlib
from train import LSTMModel, Config

LOG_TO_FILE = True
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "daemon.log")

def log(msg):
    line = f"[daemon] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    if LOG_TO_FILE:
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

def find_mt5_files_paths():
    """Return a list of candidate MT5 .../MQL5/Files folders (handles multiple terminals)."""
    # Allow override via env var
    override = os.environ.get("MT5_FILES_DIR")
    if override and os.path.isdir(override):
        return [override]

    candidates = []
    base_paths = [
        r"C:\Users\%USERNAME%\AppData\Roaming\MetaQuotes\Terminal",
        r"C:\Users\Public\AppData\Roaming\MetaQuotes\Terminal",
        os.path.expanduser(r"~\AppData\Roaming\MetaQuotes\Terminal"),
    ]
    for base in base_paths:
        base = os.path.expandvars(base)
        if not os.path.isdir(base):
            continue
        for folder in os.listdir(base):
            # Terminal IDs are 32 hex chars
            if len(folder) == 32 and all(c in "0123456789ABCDEFabcdef" for c in folder):
                files_path = os.path.join(base, folder, "MQL5", "Files")
                if os.path.isdir(files_path):
                    candidates.append(files_path)
    return sorted(set(candidates))

cfg = Config()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = None
feature_scaler = None
label_scaler = None

def load_models_and_scalers():
    global model, feature_scaler, label_scaler
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, cfg.MODEL_PATH)
        fscaler_path = os.path.join(script_dir, cfg.FEATURE_SCALER_PATH)
        lscaler_path = os.path.join(script_dir, cfg.LABEL_SCALER_PATH)

        log(f"Loading model: {model_path}")
        log(f"Loading feature scaler: {fscaler_path}")
        log(f"Loading label scaler: {lscaler_path}")

        if not os.path.exists(model_path) or not os.path.exists(fscaler_path) or not os.path.exists(lscaler_path):
            raise FileNotFoundError("One or more model/scaler files missing. Run train.py first.")

        model = LSTMModel(input_dim=cfg.FEATURE_COUNT, hidden_dim=100, output_dim=cfg.PREDICTION_STEPS, n_layers=2)
        state = torch.load(model_path, map_location=device)
        model.load_state_dict(state)
        model.to(device)
        model.eval()

        feature_scaler = joblib.load(fscaler_path)
        label_scaler = joblib.load(lscaler_path)

        # Sanity checks
        nfeat = getattr(feature_scaler, "n_features_in_", cfg.FEATURE_COUNT)
        if nfeat != cfg.FEATURE_COUNT:
            raise ValueError(f"Feature count mismatch: scaler expects {nfeat}, cfg has {cfg.FEATURE_COUNT}")
        if getattr(label_scaler, "n_features_in_", cfg.PREDICTION_STEPS) != cfg.PREDICTION_STEPS:
            raise ValueError("Label scaler output dims mismatch")

        log("✅ Models and scalers loaded and validated.")
        return True
    except Exception as e:
        log(f"FATAL while loading models: {e}")
        log(traceback.format_exc())
        return False

def generate_probabilities(predicted_prices, current_price):
    price_changes = predicted_prices - current_price
    avg_change = float(np.mean(price_changes))
    sensitivity = 2000.0
    buy_logit = max(0.0, avg_change) * sensitivity
    sell_logit = max(0.0, -avg_change) * sensitivity
    exp_buy = np.exp(min(buy_logit, 20))   # clip to avoid overflow
    exp_sell = np.exp(min(sell_logit, 20))
    buy_prob = float(exp_buy / (1.0 + exp_buy + exp_sell))
    sell_prob = float(exp_sell / (1.0 + exp_buy + exp_sell))
    return buy_prob, sell_prob

def generate_confidence(predicted_prices, atr):
    spread = float(np.std(predicted_prices))
    avg_predicted_change = float(abs(np.mean(predicted_prices) - predicted_prices[0]))
    denom = float(atr) + 1e-9
    normalized_spread = 1.0 - min(1.0, spread / denom)
    normalized_magnitude = min(1.0, avg_predicted_change / denom)
    confidence = (normalized_spread * 0.4) + (normalized_magnitude * 0.6)
    return max(0.0, min(1.0, float(confidence)))

def stable_read_json(path, attempts=8, delay=0.15):
    """Read JSON only when the file size is stable and content parses."""
    last_size = -1
    for i in range(attempts):
        try:
            size = os.path.getsize(path)
            if size == 0:
                time.sleep(delay)
                continue
            if size == last_size:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            last_size = size
        except Exception as e:
            time.sleep(delay)
    raise IOError("File not stable / unreadable")

def process_request(request_data):
    try:
        features_flat = request_data.get("features") or []
        current_price = float(request_data.get("current_price", 0.0))
        atr_val = float(request_data.get("atr", 0.0))
        req_id = str(request_data.get("request_id", ""))

        if len(features_flat) != cfg.SEQ_LEN * cfg.FEATURE_COUNT:
            return {"status": "error", "message": f"Invalid features length {len(features_flat)}; expected {cfg.SEQ_LEN * cfg.FEATURE_COUNT}", "request_id": req_id}

        features_np = np.array(features_flat, dtype=np.float32).reshape(cfg.SEQ_LEN, cfg.FEATURE_COUNT)
        features_scaled = feature_scaler.transform(features_np)
        features_tensor = torch.tensor([features_scaled], dtype=torch.float32, device=device)

        with torch.no_grad():
            prediction_scaled = model(features_tensor).cpu().numpy()

        predicted_prices = label_scaler.inverse_transform(prediction_scaled)[0].astype(float)

        buy_prob, sell_prob = generate_probabilities(predicted_prices, current_price)
        confidence = generate_confidence(predicted_prices, atr_val)

        return {
            "status": "success",
            "request_id": req_id,
            "predicted_prices": predicted_prices.tolist(),
            "confidence_score": confidence,
            "buy_probability": buy_prob,
            "sell_probability": sell_prob
        }
    except Exception as e:
        log(f"ERROR inside process_request: {e}")
        log(traceback.format_exc())
        return {"status": "error", "message": f"Daemon processing error: {e}", "request_id": request_data.get("request_id", "")}

def watch_for_requests():
    paths = find_mt5_files_paths()
    if not paths:
        log("❌ No MT5 Files directories found. Start MetaTrader once, then retry.")
        return
    log("Monitoring folders:")
    for p in paths: log(f" - {p}")

    seen = set()
    while True:
        try:
            for root in paths:
                try:
                    files = [f for f in os.listdir(root) if f.startswith("request_") and f.endswith(".json")]
                except Exception:
                    continue
                for name in files:
                    fq = os.path.join(root, name)
                    key = (root, name)
                    if key in seen:
                        continue
                    # Skip temp/partial files
                    if name.endswith(".part") or name.endswith(".tmp"):
                        continue
                    log(f"Processing {fq}")
                    try:
                        data = stable_read_json(fq)
                    except Exception as e:
                        log(f"Failed to read (unstable) {name}: {e}; removing to unblock.")
                        try: os.remove(fq)
                        except: pass
                        seen.add(key)
                        continue

                    resp = process_request(data)
                    resp_name = f"response_{data.get('request_id','unknown')}.json"
                    resp_path_tmp = os.path.join(root, resp_name + ".part")
                    resp_path = os.path.join(root, resp_name)
                    try:
                        with open(resp_path_tmp, "w", encoding="utf-8") as f:
                            json.dump(resp, f, indent=2)
                        os.replace(resp_path_tmp, resp_path)  # atomic on Windows
                        log(f"✅ Wrote {resp_path}")
                    except Exception as e:
                        log(f"ERROR writing response: {e}")
                    # Clean up request file
                    try:
                        os.remove(fq)
                    except Exception as e:
                        log(f"Warn: could not remove request file: {e}")
                    seen.add(key)

            if len(seen) > 5000:
                seen.clear()
            time.sleep(0.1)
        except KeyboardInterrupt:
            log("Stopping daemon (Ctrl+C).")
            break
        except Exception as e:
            log(f"Loop error: {e}")
            log(traceback.format_exc())
            time.sleep(1.0)

if __name__ == "__main__":
    log("=== LSTM Daemon (fixed) starting ===")
    ok = load_models_and_scalers()
    if ok:
        watch_for_requests()
    else:
        sys.exit(1)
