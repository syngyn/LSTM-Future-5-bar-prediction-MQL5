# backtest_fixed2.py — robust CSV loader (datetime/close autodetect) + predictions
import os, pandas as pd, numpy as np, torch, joblib, shutil, csv
from tqdm import tqdm
from train import LSTMModel, Config, create_features

COMMON_SEPS = [",", ";", "\t", "|"]

def sniff_sep(sample_path: str, default=","):
    try:
        with open(sample_path, "rb") as f:
            head = f.read(65536)
        dialect = csv.Sniffer().sniff(head.decode("utf-8", errors="ignore"))
        return dialect.delimiter
    except Exception:
        return default

def load_csv_with_datetime(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV not found: {path}")

    sep = sniff_sep(path, default=",")
    try:
        df = pd.read_csv(path, sep=sep)
    except Exception:
        last_err = None
        for s in COMMON_SEPS:
            try:
                df = pd.read_csv(path, sep=s)
                sep = s
                break
            except Exception as e:
                last_err = e
        else:
            raise last_err

    # Find datetime-ish column
    cols_lower = {str(c).lower(): c for c in df.columns}
    candidates = []
    for key in ("datetime", "time", "timestamp", "date"):
        if key in cols_lower:
            candidates.append(cols_lower[key])

    if not candidates:
        # try first column if parseable
        first = df.columns[0]
        try:
            pd.to_datetime(df[first], errors="raise")
            candidates = [first]
        except Exception:
            pass

    if not candidates:
        raise ValueError(f"No datetime-like column found. Columns = {list(df.columns)} (sep='{sep}')")

    dt_col = candidates[0]
    df[dt_col] = pd.to_datetime(df[dt_col], errors="coerce")
    df = df.dropna(subset=[dt_col])
    df = df.set_index(dt_col).sort_index()

    # Find close/price column
    price_candidates = []
    for key in ("close", "c", "last", "price"):
        if key in cols_lower:
            price_candidates.append(cols_lower[key])
            break
    if not price_candidates:
        for c in df.columns:
            lc = str(c).lower()
            if "close" in lc or lc.endswith("bid") or lc.endswith("ask") or lc.endswith("_c"):
                price_candidates.append(c)
                break
    if not price_candidates:
        raise ValueError(f"No close/price-like column found. Columns = {list(df.columns)} (sep='{sep}')")

    close_col = price_candidates[0]
    if close_col != "Close":
        df = df.rename(columns={close_col: "Close"})

    return df

def find_mt5_files_paths():
    paths = []
    base_paths = [
        r"C:\Users\%USERNAME%\AppData\Roaming\MetaQuotes\Terminal",
        r"C:\Users\Public\AppData\Roaming\MetaQuotes\Terminal",
        os.path.expanduser(r"~\AppData\Roaming\MetaQuotes\Terminal"),
    ]
    for base in base_paths:
        base = os.path.expandvars(base)
        if not os.path.isdir(base):
            continue
        for folder in os.listdir(base):
            files_dir = os.path.join(base, folder, "MQL5", "Files")
            if len(folder) == 32 and os.path.isdir(files_dir):
                paths.append(files_dir)
    return sorted(set(paths))

def generate_probabilities(predicted_prices, current_price):
    # same logic as the daemon for consistency
    price_changes = predicted_prices - current_price
    avg_change = float(np.mean(price_changes))
    sensitivity = 2000.0
    buy_logit = max(0.0, avg_change) * sensitivity
    sell_logit = max(0.0, -avg_change) * sensitivity
    exp_buy = np.exp(min(buy_logit, 20))
    exp_sell = np.exp(min(sell_logit, 20))
    buy_prob = float(exp_buy / (1.0 + exp_buy + exp_sell))
    sell_prob = float(exp_sell / (1.0 + exp_buy + exp_sell))
    return buy_prob, sell_prob

def generate_confidence(predicted_prices, atr):
    spread = float(np.std(predicted_prices))
    avg_predicted_change = float(abs(np.mean(predicted_prices) - predicted_prices[0]))
    denom = float(atr) + 1e-9
    normalized_spread = 1.0 - min(1.0, spread / denom)
    normalized_magnitude = min(1.0, avg_predicted_change / denom)
    confidence = (normalized_spread * 0.4) + (normalized_magnitude * 0.6)
    return max(0.0, min(1.0, float(confidence)))

def run_backtest(config):
    print("--- Starting Backtest Prediction Generation ---")
    device = torch.device("cpu")
    model = LSTMModel(input_dim=config.FEATURE_COUNT, hidden_dim=100, output_dim=config.PREDICTION_STEPS, n_layers=2)

    try:
        model.load_state_dict(torch.load(config.MODEL_PATH, map_location=device))
    except FileNotFoundError:
        print(f"❌ Model not found: {config.MODEL_PATH}  (Run train.py first.)")
        return
    model.to(device); model.eval()

    feature_scaler = joblib.load(config.FEATURE_SCALER_PATH)
    label_scaler   = joblib.load(config.LABEL_SCALER_PATH)

    main_df_path = os.path.join(config.DATA_DIR, f"{config.MAIN_SYMBOL_MQL5}.csv")
    if not os.path.exists(main_df_path):
        print(f"❌ Data not found: {main_df_path}")
        return

    try:
        main_df = load_csv_with_datetime(main_df_path)
    except Exception as e:
        print(f"❌ Failed to load CSV with datetime: {e}")
        return

    # Build features via your pipeline
    processed = create_features(main_df.copy(), config)
    if processed.empty:
        print("❌ Feature engineering returned empty. Check your create_features() and data.")
        return

    feat_cols = [c for c in processed.columns if c.startswith("f")]
    if not feat_cols:
        print("❌ No engineered feature columns (prefix 'f'). Check create_features().")
        return

    X = processed[feat_cols].values
    Xs = feature_scaler.transform(X)

    preds = []
    steps = config.SEQ_LEN
    for i in tqdm(range(len(Xs) - steps), desc="Backtesting"):
        seq = Xs[i:i+steps]
        ts = processed.index[i + steps - 1]

        # align current price
        try:
            current_price = float(main_df.loc[ts]["Close"])
        except Exception:
            ts2 = main_df.index.asof(ts)
            current_price = float(main_df.loc[ts2]["Close"])

        # get any ATR-like engineered col if available
        atr_col = next((c for c in processed.columns if "atr" in c.lower()), None)
        atr_val = float(processed.loc[ts][atr_col]) if atr_col else 1e-3

        with torch.no_grad():
            yhat_s = model(torch.tensor([seq], dtype=torch.float32)).cpu().numpy()
        yhat = label_scaler.inverse_transform(yhat_s)[0]

        buy_prob, sell_prob = generate_probabilities(yhat, current_price)
        hold_prob = 1.0 - buy_prob - sell_prob
        confidence = generate_confidence(yhat, atr_val)

        row = {
            "timestamp": ts.strftime("%Y.%m.%d %H:%M:%S"),
            "buy_prob": buy_prob,
            "sell_prob": sell_prob,
            "hold_prob": hold_prob,
            "confidence_score": confidence,
        }
        for k in range(config.PREDICTION_STEPS):
            row[f"predicted_price_h{k+1}"] = float(yhat[k])
        preds.append(row)

    if not preds:
        print("❌ No predictions produced.")
        return

    out = pd.DataFrame(preds)
    out_path = "backtest_predictions.csv"
    out.to_csv(out_path, sep=";", index=False, float_format="%.8f")
    print(f"✅ Wrote {len(out)} rows to {out_path}")

    # Optional: copy to all MT5 Files dirs so your EA can pick it up
    mt5_paths = find_mt5_files_paths()
    if mt5_paths:
        for p in mt5_paths:
            try:
                shutil.copy2(out_path, os.path.join(p, "backtest_predictions.csv"))
                print(f"Copied to {p}")
            except Exception as e:
                print(f"Warn: could not copy to {p}: {e}")
    else:
        print("Note: No MT5 Files directories found to copy output.")

if __name__ == "__main__":
    cfg = Config()
    run_backtest(cfg)