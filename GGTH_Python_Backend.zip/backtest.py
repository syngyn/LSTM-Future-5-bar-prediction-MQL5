# backtest.py (FINAL CORRECTED VERSION for Timezone issue)

import os
import pandas as pd
import numpy as np
import torch
import joblib
from tqdm import tqdm
# We need to import the functions from our other scripts
from train import LSTMModel, Config, create_features
from daemon import generate_probabilities, generate_confidence

def run_backtest(config):
    """
    Generates predictions for the historical dataset to be used by the MT5 Strategy Tester.
    """
    print("--- Starting Backtest Prediction Generation ---")
    print("Loading models, scalers, and data...")
    try:
        device = torch.device("cpu")
        model = LSTMModel(input_dim=config.FEATURE_COUNT, hidden_dim=100, output_dim=config.PREDICTION_STEPS, n_layers=2)
        model.load_state_dict(torch.load(config.MODEL_PATH, map_location=device))
        model.to(device)
        model.eval()
        feature_scaler = joblib.load(config.FEATURE_SCALER_PATH)
        label_scaler = joblib.load(config.LABEL_SCALER_PATH)
        
        main_df_path = os.path.join(config.DATA_DIR, f"{config.MAIN_SYMBOL_MQL5}.csv")
        
        # FINAL FIX: Make this DataFrame timezone-aware to match the other one
        # This resolves the "tz-naive vs tz-aware" error
        main_df = pd.read_csv(
            main_df_path, 
            index_col='Datetime', 
            parse_dates=True, 
            encoding='utf-8-sig', 
            sep='\t'
        )
        main_df.index = pd.to_datetime(main_df.index, utc=True)

    except FileNotFoundError as e:
        print(f"❌ ERROR: Could not find a required file: {e}. Please run train.py first.")
        return

    # Create features for the entire dataset
    # The 'processed_data' DataFrame will have a timezone-aware index
    processed_data = create_features(main_df.copy(), config)
    
    feature_cols = [col for col in processed_data.columns if col.startswith('f')]
    X_full = processed_data[feature_cols].values
    X_full_scaled = feature_scaler.transform(X_full)

    print("\n--- Generating predictions for each time step ---")
    predictions = []
    num_predictions = len(X_full_scaled) - config.SEQ_LEN
    for i in tqdm(range(num_predictions), desc="Backtesting"):
        feature_seq = X_full_scaled[i : i + config.SEQ_LEN]
        
        # This timestamp is timezone-AWARE
        prediction_timestamp = processed_data.index[i + config.SEQ_LEN - 1]
        
        # Now we can look it up in the timezone-AWARE main_df
        current_price = main_df.loc[prediction_timestamp]['Close']
        atr_val = processed_data.loc[prediction_timestamp]['f3_atr']
        
        features_tensor = torch.tensor([feature_seq], dtype=torch.float32).to(device)
        with torch.no_grad():
            prediction_scaled = model(features_tensor).cpu().numpy()
        
        predicted_prices = label_scaler.inverse_transform(prediction_scaled)[0]
        buy_prob, sell_prob = generate_probabilities(predicted_prices, current_price)
        hold_prob = 1.0 - buy_prob - sell_prob
        confidence = generate_confidence(predicted_prices, atr_val)
        
        result = {
            "timestamp": prediction_timestamp,
            "buy_prob": buy_prob,
            "sell_prob": sell_prob,
            "hold_prob": hold_prob,
            "confidence_score": confidence,
        }
        for step in range(config.PREDICTION_STEPS):
            result[f"predicted_price_h{step+1}"] = predicted_prices[step]
        predictions.append(result)

    if not predictions:
        print("❌ No predictions were generated. Check data processing steps.")
        return
        
    results_df = pd.DataFrame(predictions)
    # Format timestamp for MQL5: YYYY.MM.DD HH:MM:SS (it is now timezone-aware, but strftime handles it)
    results_df['timestamp'] = results_df['timestamp'].dt.strftime('%Y.%m.%d %H:%M:%S')
    
    output_path = "backtest_predictions.csv"
    print(f"\n--- Saving {len(results_df)} predictions to {output_path} ---")
    results_df.to_csv(output_path, sep=';', index=False, header=True, float_format='%.8f')
    
    # Path to MQL5 common files
    try:
        common_files_path = os.path.join(os.getenv('APPDATA'), 'MetaQuotes', 'Terminal', 'Common', 'Files')
        print("\n✅ Backtest prediction file generated successfully.")
        print(f"IMPORTANT: Copy '{output_path}' to your MetaTrader 5 Common/Files directory.")
        print(f"Path is usually: {common_files_path}")
    except Exception:
        print("\n✅ Backtest prediction file generated successfully.")
        print(f"IMPORTANT: Copy '{output_path}' to your MetaTrader 5 Common/Files directory.")


if __name__ == "__main__":
    cfg = Config()
    run_backtest(cfg)